# b = "b'1234'"
# Dict            = eval(b)

# print(Dict.decode('utf-8'))
# print(type(Dict))

# import json

# try:
# 	# file_json = open("json/file.json")
# 	# data 	  = json.loads(file_json.read())
# 	# data2	  = data.replace("\'","")
# 	# data3 	  = eval(data2)
# 	# print(type(data3))
# 	print([value for value, key in data3.items()])
# except:
# 	print('failed')


import urllib.request
import urllib.parse

url 			= 'http://localhost/sii/check_data.php'
data 			= {'kode':"b'33GG'"}
headers 		= {'application/json; charset=utf-8'}
post_data 		= urllib.parse.urlencode(data).encode()
post_response 	= urllib.request.urlopen(url=url, data=post_data)
text_res 		= post_response.read()
text_str 		= text_res.decode("utf-8")
print(text_str)