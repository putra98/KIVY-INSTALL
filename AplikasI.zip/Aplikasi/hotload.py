
from kivy.lang import Builder

from kivymd.app import MDApp
from kivy.utils import platform
from kivy.core.window import Window
Window.keyboard_anim_args = {'d': .2, 't': 'in_out_expo'}
Window.softinput_mode = "below_target"

from kivy.config import Config



KV = '''
#:import KivyLexer kivy.extras.highlight.KivyLexer
#:import HotReloadViewer kivymd.utils.hot_reload_viewer.HotReloadViewer


BoxLayout:

    # CodeInput:
    #     lexer: KivyLexer()
    #     style_name: "native"
    #     color:1,1,200,1
    #     on_text: app.update_kv_file(self.text)
    #     size_hint_x: .7

    HotReloadViewer:
        size_hint_x: .3
        path: app.path_to_kv_file
        errors: True
        errors_text_color: 200, 0, 0, 1
        errors_background_color: app.theme_cls.bg_dark
'''


class Example(MDApp):
    path_to_kv_file = "C:\\Users\\shihab\\Desktop\\KKP\\Aplikasi\\libs\\kv\\scan_screen.kv"
    # path_to_kv_file = "/media/shihab/SHIHAB/Dataapp/Python Project/Kivy/Project Kivy/market/view.kv"
    Config.set("graphics","width",360)
    Config.set("graphics","height",740)
    def build(self):
        self.theme_cls.theme_style = "Light"
        return Builder.load_string(KV)

    def update_kv_file(self, text):
        with open(self.path_to_kv_file, "w") as kv_file:
            kv_file.write(text)


Example().run()

