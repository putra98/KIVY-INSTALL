from kivy.uix.boxlayout import BoxLayout 

class Dashboard(BoxLayout):
	pass