import os
import kivy
from kaki.app import App
from kivy.uix.button import Button 
os.environ['KIVY_GL_BACKEND'] = 'angle_sdl2'
from kivy.factory import Factory 


class MainApp(App):

    DEBUG = 1
    KV_FILES = {
        os.path.join(os.getcwd(), "view/dashboard.kv")
    }
    CLASSES = {
        "Dashboard": "view.dashboard"
    }
    AUTORELOADER_PATHS = [
        (".", {"recursive": True})
    ]

    def build_app(self):

        return Factory.Dashboard()

MainApp().run()